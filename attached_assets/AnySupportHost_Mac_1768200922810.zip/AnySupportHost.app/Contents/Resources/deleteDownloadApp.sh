#!/bin/sh

#  deleteDownloadApp.sh
#  AnySupportHost
#
#  Created by HyeokHee Lee on 2018. 4. 26..
#  
sleep 2
rm -rf ~/Downloads/AnySupportHost*
