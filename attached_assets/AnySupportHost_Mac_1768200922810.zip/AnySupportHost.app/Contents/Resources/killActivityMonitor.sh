#!/bin/sh

#  killActivityMonitor.sh
#  AnySupportHost
#
#  Created by HyeokHee Lee on 2018. 4. 26..
#

cd /Applications/Utilities/Activity\ Monitor.app/Contents/MacOS/ | killall -9 Activity\ Monitor
